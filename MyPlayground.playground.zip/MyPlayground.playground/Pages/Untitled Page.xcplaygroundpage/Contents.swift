//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
// str=18
print(str)

let inge="guapo"

//inge="feo"
/*
 este es un comentario
 */
//String
//Int
//Double
//Float
//Boll

var edad: Int=18
print(edad)

var deuda = 19.0
type(of:deuda)

// + - / * %
var x = 10
var y = 20
x + y
x + -y

"hola " + "muchachos"

/*
 Ser descriptivo con los comandos
 Las estructuras empiezan con mayusculas
 */

var numeroGrande = 1000000
numeroGrande = 1_000_000

var 🤨 = "ehhh?"
var perro = "🐶"
print(perro)
//Programar en ingles
//Incremento y decremento
var counter = 1
counter += 1
counter -= 1
counter *= 5
